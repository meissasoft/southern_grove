<?php

include_once QODE_CORE_SHORTCODES_PATH . '/hiding-images/functions.php';
include_once QODE_CORE_SHORTCODES_PATH . '/hiding-images/hiding-images.php';
include_once QODE_CORE_SHORTCODES_PATH . '/hiding-images/hiding-image.php';