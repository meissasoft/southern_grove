<div class="qodef-image-marquee-holder">
    <div class="qodef-image-marquee">
        <div class="qodef-image qodef-original">
            <img src="<?php echo wp_get_attachment_url($image); ?>" alt="<?php echo get_the_title($image) ?>" />
        </div>
        <div class="qodef-image qodef-aux">
            <img src="<?php echo wp_get_attachment_url($image); ?>" alt="<?php echo get_the_title($image) ?>" />
        </div>
    </div>
</div>