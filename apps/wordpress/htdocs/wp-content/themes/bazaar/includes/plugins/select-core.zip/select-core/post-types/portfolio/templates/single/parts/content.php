<div class="qodef-ps-info-item qodef-ps-content-item">
    <?php the_content(); ?>
</div>