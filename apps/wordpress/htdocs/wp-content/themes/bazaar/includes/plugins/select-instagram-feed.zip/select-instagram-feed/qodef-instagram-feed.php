<?php
/*
Plugin Name: Select Instagram Feed
Description: Plugin that adds Instagram feed functionality to our theme
Author: Select Themes
Version: 2.0
*/
define( 'QODEF_INSTAGRAM_FEED_VERSION', '2.0' );

include_once 'load.php';