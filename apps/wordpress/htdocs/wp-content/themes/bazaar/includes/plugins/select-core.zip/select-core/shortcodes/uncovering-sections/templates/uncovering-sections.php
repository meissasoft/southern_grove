<div class="qodef-uncovering-sections">
	<ul class="qodef-us-wrapper curtains" data-image-holder-name=".qodef-uss-image-holder" data-fade-element-name=".qodef-fss-shadow">
		<?php echo do_shortcode($content); ?>
	</ul>
    <div class="qodef-fss-shadow"></div>
</div>