<?php

include_once QODE_CORE_SHORTCODES_PATH . '/pie-chart/functions.php';
include_once QODE_CORE_SHORTCODES_PATH . '/pie-chart/pie-chart.php';