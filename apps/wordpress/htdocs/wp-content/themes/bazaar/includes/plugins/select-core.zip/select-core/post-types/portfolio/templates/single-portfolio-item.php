<?php

get_header();

bazaar_qodef_get_title();

get_template_part('slider');

qodef_core_get_single_portfolio();

get_footer();